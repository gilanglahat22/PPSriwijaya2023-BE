<?php

namespace Database\Seeders;

use App\Models\VoteCount;
use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class VoteCountSeeder extends Seeder
{
    /**
     * Run the database seeds.
     */
    public function run(): void
    {
        VoteCount::create([
            'count_vote_men' => 1,
            'count_vote_girl' => 3,
        ]);
    }
}
